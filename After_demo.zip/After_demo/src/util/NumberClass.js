import React, { Component } from 'react';

class NumberClass extends Component {

	format_number(currency, typ, num){
		return ( new Intl.NumberFormat(typ, { style: 'currency',
											  currency: currency,
											  maximumSignificantDigits: 4,
											}).format(num).replace("€", "").trim()

				);
	}

	render() { return ( <React.Fragment>
							{this.format_number('EUR', 'de-DE', this.props.number)}
						</React.Fragment>          
					   );
	}
}
export default NumberClass;
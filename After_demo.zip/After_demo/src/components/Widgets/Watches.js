import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';

//watch images
import Runtime from '../../Assets/img/runtime_icon.png';
import Total from '../../Assets/img/Total_icon.png';
import Stops from '../../Assets/img/Total_icon-03.png';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

const imageRuntime = {
		width: '65px',
		marginTop: '5%'
}

const textStyle = {
	fontSize: '24px',
	padding: '5px'
}

const hrsStyle = {
	fontSize: '35px', 
	color: '#008bff'
}

class index extends Component { 
	render() { 
		return (
				<div>
				<RctCollapsibleCard
				colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4 left-align"
				>
					<div className="text-center">
						<img style={imageRuntime} src={Runtime} />
					</div>
					<div className="text-center" style={textStyle}>
						Runtime
					</div>
					<div className="text-center" style={hrsStyle}>
						01:23 Hrs 
					</div>
				</RctCollapsibleCard>
				<RctCollapsibleCard
					colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4 left-align"
				>
					<div className="text-center">
						<img style={imageRuntime} src={Total} />
					</div>
					<div className="text-center" style={textStyle}>
						Total
					</div>
					<div className="text-center" style={hrsStyle}>
						01:23 Hrs
					</div>
				</RctCollapsibleCard>
				<RctCollapsibleCard
					colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4 left-align"
				>
					<div className="text-center">
						<img style={imageRuntime} src={Stops} />
					</div>
					<div className="text-center" style={textStyle}>
						Stops
					</div>
					<div className="text-center" style={hrsStyle}>
						01:23 Hrs
					</div>
				</RctCollapsibleCard>
			</div>
				 
		);}
}
export default index;
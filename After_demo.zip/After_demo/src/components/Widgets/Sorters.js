/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

import {Link} from 'react-router-dom';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import { ProgressBar } from 'react-bootstrap';
import Grid from '@material-ui/core/Grid';
import NumberClass from 'Util/NumberClass';

const headingGrid = {
		textAlign: 'left',
		height: '25px',
		fontSize: 'large',
		padding: '5px'
};

const headingGrid2 = {
		textAlign: 'left',
		height: '25px',
	    fontSize: 'medium',
		padding: '5px 5px 30px 5px'
};

const headingGrid3 = {
		height: '25px',
	    fontSize: 'medium',
		padding: '5px'
};

const bottomGrid = {
		textAlign: 'left',
		height: '25px',
	    fontSize: 'xx-large',
		padding: '5px'
};

const mainGrid = {
		padding: '25px',
		height: '170px',
};

const gridContent = {
		height: '40px',
		padding: '0px',
		fontSize: 'xx-large'	
};

class Sorters extends Component {

	state = { data: [] }

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}

	// recent orders
	getRecentOrders() {
		api.get(baseURL+'sorterdata/'+ sessionStorage.getItem("username") )
		 .then(res => {
			    console.log(res.data);
			    this.setState({ data: res.data }); 
			}).catch(function (error) {
				console.log(error);
		  });
	}

	render() {
		const { recentOrders } = this.state;
		const sorters = (data) => {
			return (
					<RctCollapsibleCard
					colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
					heading={data.sorterId}
					fullBlock
					>
						<div className="clearfix">
		                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">  
		      
		                <Grid container>
						<Grid style={mainGrid} container spacing={24}>
							<Grid item xs={4} sm={4}>
							<Grid style={headingGrid2} item xs={12} sm={12}>
								Inducts for last hour
							</Grid>
								<Grid style={headingGrid2} item xs={12} sm={12}>
									<ProgressBar style={{height: '5px'}} bsStyle={"success"} now={data.inductsLastHourPercentage} />
								</Grid>
								
								<Grid style={bottomGrid} item xs={12} sm={12}>
									<NumberClass  number= {data.inducts_last_hour} />
								</Grid>
							</Grid>
							
							<Grid item xs={4} sm={4}>
								<Grid style={headingGrid2} item xs={12} sm={12}>
									Sorts for last hour
								</Grid>
							
								<Grid style={headingGrid2} item xs={12} sm={12}>
									<ProgressBar style={{height: '5px'}} bsStyle={"danger"} now={data.sortsPercentage} />
								</Grid>
						
								<Grid style={bottomGrid} item xs={12} sm={12}>
									<NumberClass  number= {data.sorts_last_hour} />
								</Grid>
							</Grid>
						
							<Grid item xs={4} sm={4} >
								<Grid style={headingGrid2} item xs={12} sm={12}>
									<div style={{float: 'left'}}>Chute Status</div>
									
								</Grid>
								
								<Grid container spacing={24}>
									<Grid item xs={12} sm={6} style={{textAlign: 'center'}}>
										<Grid style={gridContent} item xs={12} sm={12}>
											{data.assignedPercentage}%
										</Grid>
										<Grid style={headingGrid3} item xs={12} sm={12}>
											Assigned
										</Grid>
									</Grid>
									<Grid item xs={12} sm={6} style={{textAlign: 'center'}}>
										<Grid style={gridContent} item xs={12} sm={12}>
											<NumberClass  number= {data.sorter_full} />
										</Grid>
										<Grid style={headingGrid3} item xs={12} sm={12}>
											Full
										</Grid>
									</Grid>
									
								</Grid>
								
							</Grid>
							<div class="right-arrow"><Link to={{ pathname: '/app/dashboard/sorterDetails', state: { data: data.sorterId } }}> <i class="ti-angle-right"></i></Link></div>

							
						</Grid>	
					</Grid>
		           </div>
		            </div>
		        </RctCollapsibleCard>
			);
		}

		return ( 
				<React.Fragment>
					{
			            this.state.data.map(data => sorters(data) )
			        }
				 </React.Fragment>
				);
	}
}

export default Sorters;

import React from 'react';
import {BrowserRouter, Route, Redirect, Switch, Link} from 'react-router-dom';

import LandingPage from './LandingPage';


const Routes = () => (
<BrowserRouter >
	<Switch>
		/*<Route path="/landingPage" component={LandingPage}/>
*/	
	</Switch>
</BrowserRouter> );
export default Routes;

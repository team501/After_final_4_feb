/**
 * Dasboard Routes
 */
import React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';

// async components
import {
   AsyncSorterDetailsComponent,
   AsyncChuteStatusComponent,
   AsyncManageEquipmentDashboard,
   AsyncInductStatusComponent
} from 'Components/AsyncComponent/AsyncComponent';

const Dashboard = ({ match }) => (
   <div className="dashboard-wrapper">
      <Switch>
         <Redirect exact from={`${match.url}/`} to={`${match.url}/manageEquipment`} />
         <Route path={`${match.url}/sorterDetails`} component={AsyncSorterDetailsComponent} />
		 <Route path={`${match.url}/manageEquipment`} component={AsyncManageEquipmentDashboard} />
         <Route path={`${match.url}/chuteStatus`} component={AsyncChuteStatusComponent} />
         <Route path={`${match.url}/inductStatus`} component={AsyncInductStatusComponent} />
      </Switch>
   </div>
);

export default Dashboard;

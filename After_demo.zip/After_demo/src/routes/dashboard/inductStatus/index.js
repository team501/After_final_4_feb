/**
 * Data Table
 */
import React from 'react';
// MUI data table 
import MUIDataTable from "mui-datatables";
//axios call
import axios from 'axios';
import {baseURL} from '../../../services/Config.js';

// MUI Theme - added to customize cell Theme  
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';

//Reloadable card
import {WatchesWidget} from "Components/Widgets";
	
class inductStatus extends React.Component {
	
	 constructor(props) {
    super(props);
	this.state = {  data: [],
					inductsVal: [],
					isLoading:true
				 };
	}
		
      
	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.onReload();
	}


	linkState = this.props.location.state === undefined ? '' : this.props.location.state.nextLink

	onReload = () => {
		axios.get(baseURL+'inductionstatus/'+ sessionStorage.getItem("username") )
			.then(res => {
				console.log(res.data); 
				let inductsVal = res.data.map(list => list.inducts_per_hour);

				this.setState({ data: res.data,
								inductsVal: inductsVal,
								isLoading:false}); 
			}).catch(function (error) {
				console.log(error);
		});
	}

	  getMuiTheme = () => createMuiTheme({
	  overrides: {
		MUIDataTableHeadCell : {
			root: {			
				padding: '4px 20px 4px 20px',	
			    fontSize: '13px',
				color: 'black',
				width:120,
				whiteSpace: 'nowrap'
				
		  }}, 
	   
		MUIDataTableBodyCell: {
		  root: {			
			  padding: '4px 20px 4px 20px',
			  fontSize: '12px',
			  //to add color to the 1st column 
			  '&:nth-child(2)': {	
				backgroundColor: '#CD5C5C',
				width: 100
			  },
			   //to add text-color to the 5th column 
			    '&:nth-child(10)': {			  
				color: '#CD5C5C',					  			
			  },
			  '&:nth-child(20)': {			  
				width: '130px',
				whiteSpace: 'nowrap'

			  }
		  }
		},
		// to remove toolBar
		MUIDataTableToolbar: {
			     root: {
			        display: 'none'
			    }
			} 
	  }
	})
	
	render() {
	    const rows = this.state.data; 
				console.log(this.state.inductsVal);				

		const columns = ["", "Runtime", "Total Inducts", "Induct/hour", "Utilization", "Peak Rate", "Peak Rate", "Average Rate", "Current user", "Last Scan"];
		
		const options = {
			filterType: 'dropdown',
			responsive: 'stacked',
			selectableRows: false // to remove the checkbox
		};
		const { match } = this.props;

		return (
			<div className="data-table-wrapper">
				<PageTitleBar 
					url="/app/dashboard/sorterDetails" 
					urlState={this.linkState}
					title={<IntlMessages id="sidebar.inductStatusTable" />} 
					match={match} 
				/>
				<RctCard>
		        <RctCardContent>
		        	<div className="contextual-link float-left chute-sub-header">
		        		Induction Status
					</div>
					<div className="contextual-link float-right ">
						<i className="ti-reload refresh-button" onClick={() => this.onReload()}></i>
					</div> 

					<MuiThemeProvider theme={this.getMuiTheme()}>
					<MUIDataTable
						data={rows.map(item => {
								console.log(item.inducts_per_hour);	
									
								return [
									"Station A",
									item.runtime,
									item.total_inducts,
									item.inducts_per_hour,
									item.utilization,
									item.peak_rate,
									item.min_rate,
									item.avg_rate,
									item.current_usr,
									item.last_scan
								]
								
							})}
						columns={columns}
						options={options}
					/>
					</MuiThemeProvider>
				</RctCardContent>
			</RctCard >
		</div>
		);
	}
}

export default inductStatus;
